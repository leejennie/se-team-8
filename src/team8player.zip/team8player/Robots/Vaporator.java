package team8player.Robots;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import static team8player.Globals.*;

public class Vaporator extends Building {

    /**
     * Robot constructor
     * @return a random RobotType
     */
    public Vaporator() {
    }

    @Override
    public void run() throws GameActionException {
        super.run();

    }
}
